# -*- coding: utf-8 -*-
# @Author: Hannah Shader
# @Date:   2023-07-07 13:27:57
# @Last Modified by:   Hannah Shader
# @Last Modified time: 2023-07-07 14:07:25
from Plugin_Development.src.data_structures.marker_utterance_dict import (
    MarkerUtteranceDict,
)
from Plugin_Development.src.data_structures.data_objects import UttObj
from Plugin_Development.src.format.output_file_manager import OutputFileManager
from gailbot import GBPluginMethods

methods = GBPluginMethods()
dependency_outputs = methods.get_utterance_objects()
output_file = OutputFileManager()
output_file.apply(dependency_outputs, methods)
