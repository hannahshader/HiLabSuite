# -*- coding: utf-8 -*-
# @Author: Hannah Shader
# @Date:   2023-07-07 13:31:16
# @Last Modified by:   Hannah Shader
# @Last Modified time: 2023-07-07 15:29:57
# -*- coding= utf-8 -*-
# @Author= Hannah Shader
# @Date:   2023-07-07 13:31:16
# @Last Modified by:   Hannah Shader
# @Last Modified time: 2023-07-07 14:16:43
import os
from typing import Dict, Union, List, Any
from pydantic import BaseModel
from gailbot.plugin import Methods, Plugin


class UttObj(BaseModel):
    start: float
    end: float
    speaker: str
    text: str


class GBPluginMethods:
    def get_utterance_objects(self) -> Dict[str, List[UttObj]]:
        ### Option for folder
        return {
            "overlap": [
                UttObj(start=5.72, end=6.02, speaker="0", text="over"),
                UttObj(start=6.02, end=6.1, speaker="0", text="a"),
                UttObj(start=6.1, end=6.48, speaker="0", text="lot"),
                UttObj(start=7.16, end=7.37, speaker="1", text="this"),
                UttObj(start=7.37, end=7.52, speaker="1", text="is"),
                UttObj(start=7.52, end=7.64, speaker="1", text="an"),
                UttObj(start=7.64, end=8.33, speaker="1", text="overlap"),
                UttObj(start=10.00, end=11.00, speaker="1", text="another"),
                UttObj(start=11.00, end=12.05, speaker="1", text="overlap"),
            ],
            "stuart and hannah": [
                UttObj(start=1.18, end=1.41, speaker="0", text="hi"),
                UttObj(start=1.41, end=2.06, speaker="0", text="Stuart"),
                UttObj(start=3.02, end=3.2, speaker="1", text="Hey"),
                UttObj(start=3.2, end=3.58, speaker="1", text="Hannah"),
                UttObj(start=7.0, end=7.50, speaker="0", text="hi"),
                UttObj(start=7.55, end=8.55, speaker="0", text="Stuart"),
                UttObj(start=8.56, end=10.00, speaker="1", text="Hey"),
                UttObj(start=10.05, end=11.00, speaker="1", text="Hannah"),
            ],
        }

    """
    
    
    """

    @property
    def output_path(self) -> str:
        return "/Users/hannahshader/Desktop/plugin-development-output/Analysis/Plugin_Development"
