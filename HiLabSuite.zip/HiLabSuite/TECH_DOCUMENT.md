Types of Logging:

logging.info

prints to the console
ex: logging.info("start pause analysis")
logging.debug

prints to the debug, inaccessible through the GUI
ex: logging.debug(f"get fto : {fto}")
logging.warn

prints out a WARNING message to the console.
says 'WARNING' and is yellow or red
ex: logging.warn(f"no time difference between sentence start and end")